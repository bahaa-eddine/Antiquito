const { createRunOncePlugin, withPodfile } = require("expo/config-plugins");

const MARKER = "# Configure a Homebrew CA bundle for CocoaPods when local trust stores are outdated.";
const SNIPPET = `${MARKER}
begin
  openssl_roots = [
    ['/usr/local/etc/ca-certificates/cert.pem', '/usr/local/etc/ca-certificates'],
    ['/opt/homebrew/etc/ca-certificates/cert.pem', '/opt/homebrew/etc/ca-certificates'],
    ['/usr/local/opt/openssl@3/etc/openssl@3/cert.pem', '/usr/local/opt/openssl@3/etc/openssl@3/certs'],
    ['/opt/homebrew/opt/openssl@3/etc/openssl@3/cert.pem', '/opt/homebrew/opt/openssl@3/etc/openssl@3/certs'],
    ['/usr/local/etc/openssl@3/cert.pem', '/usr/local/etc/openssl@3/certs'],
    ['/opt/homebrew/etc/openssl@3/cert.pem', '/opt/homebrew/etc/openssl@3/certs'],
    ['/usr/local/opt/openssl@1.1/etc/openssl@1.1/cert.pem', '/usr/local/opt/openssl@1.1/etc/openssl@1.1/certs'],
    ['/opt/homebrew/opt/openssl@1.1/etc/openssl@1.1/cert.pem', '/opt/homebrew/opt/openssl@1.1/etc/openssl@1.1/certs']
  ]

  cert_file, cert_dir = openssl_roots.find { |file, _dir| File.exist?(file) }

  if cert_file
    ENV['SSL_CERT_FILE'] = cert_file
    ENV['CURL_CA_BUNDLE'] = cert_file
    ENV['SSL_CERT_DIR'] = cert_dir if cert_dir && Dir.exist?(cert_dir)
  end
rescue => e
  Pod::UI.warn("Unable to configure CocoaPods CA bundle fallback: #{e}")
end

`;

function withCocoaPodsCert(config) {
  return withPodfile(config, (config) => {
    if (!config.modResults.contents.includes(MARKER)) {
      config.modResults.contents = `${SNIPPET}${config.modResults.contents}`;
    }

    return config;
  });
}

module.exports = createRunOncePlugin(
  withCocoaPodsCert,
  "with-cocoapods-cert",
  "1.0.0"
);
