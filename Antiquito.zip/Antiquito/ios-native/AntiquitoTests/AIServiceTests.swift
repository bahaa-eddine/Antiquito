import XCTest
@testable import Antiquito

final class AIServiceTests: XCTestCase {

    func testConfidenceLabelMapping() {
        XCTAssertEqual(AIService.getConfidenceLabel(10), "Almost Certainly a Reproduction")
        XCTAssertEqual(AIService.getConfidenceLabel(25), "Likely a Reproduction")
        XCTAssertEqual(AIService.getConfidenceLabel(40), "Probably a Reproduction")
        XCTAssertEqual(AIService.getConfidenceLabel(50), "Inconclusive")
        XCTAssertEqual(AIService.getConfidenceLabel(65), "Probably Authentic")
        XCTAssertEqual(AIService.getConfidenceLabel(80), "Likely Authentic")
        XCTAssertEqual(AIService.getConfidenceLabel(95), "Highly Authentic")
    }

    func testAuthenticityMapping() {
        XCTAssertEqual(AIService.getAuthenticity(0),  .reproduction)
        XCTAssertEqual(AIService.getAuthenticity(45), .reproduction)
        XCTAssertEqual(AIService.getAuthenticity(46), .inconclusive)
        XCTAssertEqual(AIService.getAuthenticity(55), .inconclusive)
        XCTAssertEqual(AIService.getAuthenticity(56), .authentic)
        XCTAssertEqual(AIService.getAuthenticity(100), .authentic)
    }

    func testBarColorMapping() {
        XCTAssertEqual(AIService.getBarColor(10), "#922B21")
        XCTAssertEqual(AIService.getBarColor(25), "#C0392B")
        XCTAssertEqual(AIService.getBarColor(40), "#D35400")
        XCTAssertEqual(AIService.getBarColor(50), "#B7770D")
        XCTAssertEqual(AIService.getBarColor(65), "#27AE60")
        XCTAssertEqual(AIService.getBarColor(80), "#1A7340")
        XCTAssertEqual(AIService.getBarColor(95), "#0D5C35")
    }
}
