# Antiquito iOS — Native Swift Project

A native Swift/SwiftUI iOS app rewritten from the Expo/React Native project.

## Requirements

- **Xcode 15.2+** (Swift 5.9.2)
- **iOS 16.0+** deployment target
- **macOS 13+** (Ventura)

## Quick Setup

### 1. Create Xcode Project

Since XcodeGen is not available on your system, create the project manually in Xcode:

1. Open **Xcode → File → New → Project**
2. Choose **iOS → App**
3. Configure:
   - **Product Name**: `Antiquito`
   - **Team**: Your development team
   - **Organization Identifier**: `com.antiquito`
   - **Bundle Identifier**: `com.antiquito.app`
   - **Interface**: **SwiftUI**
   - **Language**: **Swift**
   - **Storage**: None
4. Save it inside `ios-native/` (this directory)
5. **Delete** the auto-generated `ContentView.swift` and `AntiquitoApp.swift` from the default project (we have our own)

### 2. Add Existing Source Files

1. In Xcode, right-click the `Antiquito` target folder
2. Choose **Add Files to "Antiquito"**
3. Navigate to `ios-native/Antiquito/` and select **all subfolders**:
   - `App/`, `Models/`, `Services/`, `Store/`, `Views/`, `Components/`, `Design/`, `Utilities/`, `Config/`, `Resources/`
4. Make sure **"Copy items if needed"** is **unchecked** (files are already in place)
5. Make sure **"Create folder references"** is selected for `Resources/Assets.xcassets`
6. Ensure all `.swift` files are added to the **Antiquito** target

### 3. Add Firebase SDK (SPM)

1. **File → Add Package Dependencies**
2. Enter URL: `https://github.com/firebase/firebase-ios-sdk`
3. Set version rule: **Up to Next Major Version** from `10.22.0`
4. Select **only** `FirebaseAuth` product
5. Add to `Antiquito` target

### 4. Configure Firebase

1. Go to [Firebase Console](https://console.firebase.google.com) → your project
2. Add an iOS app with bundle ID `com.antiquito.app`
3. Download `GoogleService-Info.plist`
4. Drag it into `Antiquito/Resources/` in Xcode

### 5. Configure Groq API Key

Add your Groq API key via Xcode scheme environment variable:

1. **Product → Scheme → Edit Scheme**
2. Under **Run → Arguments → Environment Variables**
3. Add: `GROQ_API_KEY` = `your-groq-api-key`

Or add it to your `Info.plist`:
```xml
<key>GROQ_API_KEY</key>
<string>your-groq-api-key</string>
```

### 6. Build & Run

1. Select an **iPhone 15** simulator (or a physical device)
2. **⌘R** to build and run

## Project Structure

```
Antiquito/
├── App/           → App entry point, Firebase configure
├── Models/        → Data models (AnalysisResult, ScanRecord, AppUser)
├── Services/      → AuthService, AIService, StoreKitService
├── Store/         → AppState (@Observable, replaces Zustand)
├── Views/         → All screens (Login, Camera, Preview, Result, etc.)
├── Components/    → Reusable UI components
├── Design/        → Colors, Spacing, Typography tokens
├── Utilities/     → Constants, helpers
├── Config/        → Secrets, API configuration
└── Resources/     → Assets, Info.plist
```

## Dependencies

| Package | Version | Purpose |
|---|---|---|
| **firebase-ios-sdk** | 10.22+ | Firebase Authentication |
| *(built-in)* | — | StoreKit 2, AVFoundation, SwiftUI |

## Feature Parity with Expo

| Feature | Expo | Swift |
|---|---|---|
| Auth | Firebase JS SDK | Firebase iOS SDK |
| Camera | expo-camera | AVFoundation |
| AI Analysis | fetch + Groq | URLSession + Codable |
| Subscriptions | react-native-iap | StoreKit 2 (native) |
| State Management | Zustand | @Observable |
| Local Storage | AsyncStorage | UserDefaults |
| Gradients | expo-linear-gradient | SwiftUI LinearGradient |
| Navigation | React Navigation | NavigationStack |
