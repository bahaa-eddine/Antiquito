#!/usr/bin/env ruby
# Generates Antiquito.xcodeproj using the xcodeproj gem (bundled with CocoaPods)

require 'xcodeproj'
require 'pathname'
require 'fileutils'

PROJECT_DIR = File.dirname(File.expand_path(__FILE__))
PROJECT_PATH = File.join(PROJECT_DIR, 'Antiquito.xcodeproj')

# Clean existing project
FileUtils.rm_rf(PROJECT_PATH)

project = Xcodeproj::Project.new(PROJECT_PATH)

# ── Build settings ──────────────────────────────────────────────────────────────

base_settings = {
  'PRODUCT_BUNDLE_IDENTIFIER' => 'com.antiquito.app',
  'MARKETING_VERSION' => '1.0.0',
  'CURRENT_PROJECT_VERSION' => '1',
  'SWIFT_VERSION' => '5.9',
  'IPHONEOS_DEPLOYMENT_TARGET' => '17.0',
  'TARGETED_DEVICE_FAMILY' => '1',
  'CODE_SIGN_STYLE' => 'Automatic',
  'INFOPLIST_FILE' => '$(SRCROOT)/Antiquito/Resources/Info.plist',
  'GENERATE_INFOPLIST_FILE' => 'NO',
  'ASSETCATALOG_COMPILER_APPICON_NAME' => 'AppIcon',
  'SWIFT_EMIT_LOC_STRINGS' => 'YES',
  'ENABLE_USER_SCRIPT_SANDBOXING' => 'YES',
  'PRODUCT_NAME' => '$(TARGET_NAME)',
}

# ── App Target ──────────────────────────────────────────────────────────────────

target = project.new_target(:application, 'Antiquito', :ios, '17.0')

target.build_configurations.each do |config|
  config.build_settings.merge!(base_settings)
  if config.name == 'Debug'
    config.build_settings['DEBUG_INFORMATION_FORMAT'] = 'dwarf'
    config.build_settings['SWIFT_OPTIMIZATION_LEVEL'] = '-Onone'
    config.build_settings['SWIFT_ACTIVE_COMPILATION_CONDITIONS'] = 'DEBUG'
  else
    config.build_settings['DEBUG_INFORMATION_FORMAT'] = 'dwarf-with-dsym'
    config.build_settings['SWIFT_OPTIMIZATION_LEVEL'] = '-O'
  end
end

# ── Add source files ────────────────────────────────────────────────────────────

source_root = File.join(PROJECT_DIR, 'Antiquito')

# Recursively add Swift files from a directory into a group
def add_swift_files(project, target, group, dir_path)
  Dir.entries(dir_path).sort.each do |entry|
    next if entry.start_with?('.')
    full_path = File.join(dir_path, entry)

    if File.directory?(full_path)
      # Skip asset catalogs — handled separately
      next if entry.end_with?('.xcassets')
      subgroup = group.new_group(entry, entry)
      add_swift_files(project, target, subgroup, full_path)
    elsif entry.end_with?('.swift')
      ref = group.new_reference(entry)
      ref.last_known_file_type = 'sourcecode.swift'
      target.source_build_phase.add_file_reference(ref)
    elsif entry == 'Info.plist'
      # Just reference it, don't add to build phase
      group.new_reference(entry)
    end
  end
end

app_group = project.main_group.new_group('Antiquito', 'Antiquito')

# Add Swift source directories
%w[App Models Services Store Design Utilities Config].each do |dir|
  dir_path = File.join(source_root, dir)
  next unless File.directory?(dir_path)
  subgroup = app_group.new_group(dir, dir)
  add_swift_files(project, target, subgroup, dir_path)
end

# Views (with subdirectories)
views_path = File.join(source_root, 'Views')
views_group = app_group.new_group('Views', 'Views')
add_swift_files(project, target, views_group, views_path)

# Components
components_path = File.join(source_root, 'Components')
components_group = app_group.new_group('Components', 'Components')
add_swift_files(project, target, components_group, components_path)

# Resources group — add Info.plist reference and Assets.xcassets
resources_path = File.join(source_root, 'Resources')
resources_group = app_group.new_group('Resources', 'Resources')

# Info.plist
resources_group.new_reference('Info.plist')

# Assets.xcassets — use absolute path to avoid double-nesting
assets_path = File.join(resources_path, 'Assets.xcassets')
assets_ref = resources_group.new_reference('Assets.xcassets')
assets_ref.source_tree = '<group>'
assets_ref.last_known_file_type = 'folder.assetcatalog'
target.resources_build_phase.add_file_reference(assets_ref)

# GoogleService-Info.plist (Firebase config)
google_plist = File.join(resources_path, 'GoogleService-Info.plist')
if File.exist?(google_plist)
  plist_ref = resources_group.new_reference('GoogleService-Info.plist')
  plist_ref.last_known_file_type = 'text.plist.xml'
  target.resources_build_phase.add_file_reference(plist_ref)
end

# ── Firebase SPM Dependency ─────────────────────────────────────────────────────

firebase_pkg = project.new(Xcodeproj::Project::Object::XCRemoteSwiftPackageReference)
firebase_pkg.repositoryURL = 'https://github.com/firebase/firebase-ios-sdk'
firebase_pkg.requirement = { 'kind' => 'upToNextMajorVersion', 'minimumVersion' => '10.22.0' }
project.root_object.package_references << firebase_pkg

# Add FirebaseAuth product dependency
firebase_auth_dep = project.new(Xcodeproj::Project::Object::XCSwiftPackageProductDependency)
firebase_auth_dep.product_name = 'FirebaseAuth'
firebase_auth_dep.package = firebase_pkg
target.package_product_dependencies << firebase_auth_dep

# Add to frameworks build phase
framework_ref = project.new(Xcodeproj::Project::Object::PBXBuildFile)
framework_ref.product_ref = firebase_auth_dep
target.frameworks_build_phase.files << framework_ref

# ── Save ────────────────────────────────────────────────────────────────────────

project.save

puts "✅ Generated #{PROJECT_PATH}"
puts "   Target: Antiquito (iOS 17.0+)"
puts "   Bundle ID: com.antiquito.app"
puts "   Firebase SDK: 10.22.0+ (FirebaseAuth)"

# Verify
swift_count = Dir.glob(File.join(source_root, '**/*.swift')).count
puts "   Swift files: #{swift_count}"
