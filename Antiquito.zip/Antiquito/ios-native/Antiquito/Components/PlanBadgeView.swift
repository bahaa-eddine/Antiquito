import SwiftUI

// MARK: - Plan Badge View

/// Shows premium status or free scan count — adapts to light/dark backgrounds.
struct PlanBadgeView: View {
    @Environment(AppState.self) private var appState
    var dark: Bool = false
    var onTap: (() -> Void)? = nil

    private var isPremium: Bool { appState.isPremium }
    private var scansLeft: Int { appState.scansRemaining }
    private var exhausted: Bool { !isPremium && scansLeft == 0 }

    private var label: String {
        if isPremium { return "PREMIUM" }
        if exhausted { return "UPGRADE" }
        return "\(scansLeft)/\(AppConstants.freeScanLimit) FREE"
    }

    private var bg: Color {
        if dark {
            return isPremium ? Color.appPrimary.opacity(0.55)
                : exhausted ? Color.appFake.opacity(0.45)
                : Color.black.opacity(0.45)
        } else {
            return isPremium ? Color(hex: "#FBF5E8")
                : exhausted ? Color.appFakeLight
                : Color.appSurfaceAlt
        }
    }

    private var border: Color {
        if dark {
            return isPremium ? Color.appPrimary
                : exhausted ? Color.appFake
                : Color.white.opacity(0.2)
        } else {
            return isPremium ? Color.appPrimary
                : exhausted ? Color.appFake
                : Color.appBorder
        }
    }

    private var textColor: Color {
        if dark {
            return isPremium ? Color.appPrimary
                : exhausted ? Color(hex: "#FF6B5B")
                : Color.white.opacity(0.85)
        } else {
            return isPremium ? Color.appPrimary
                : exhausted ? Color.appFake
                : Color.appTextSecondary
        }
    }

    var body: some View {
        Button {
            onTap?()
        } label: {
            HStack(spacing: 4) {
                if isPremium {
                    Image(systemName: "trophy.fill")
                        .font(.system(size: 11))
                }
                if exhausted {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 11))
                }
                Text(label)
                    .font(.system(size: 10, weight: .bold))
                    .tracking(0.8)
            }
            .foregroundStyle(textColor)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(bg, in: Capsule())
            .overlay(Capsule().stroke(border, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(onTap == nil)
    }
}
