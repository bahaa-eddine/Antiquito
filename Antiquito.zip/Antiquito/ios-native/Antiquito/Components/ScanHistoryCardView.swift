import SwiftUI

// MARK: - Scan History Card View

/// List card for scan history — shows thumbnail, title, period, badge, and date.
struct ScanHistoryCardView: View {
    let record: ScanRecord
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: Spacing.md) {
                // Thumbnail
                if let uiImage = UIImage(data: record.imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 72, height: 72)
                        .clipShape(RoundedRectangle(cornerRadius: Radius.md))
                        .background(Color.appSurfaceAlt, in: RoundedRectangle(cornerRadius: Radius.md))
                } else {
                    RoundedRectangle(cornerRadius: Radius.md)
                        .fill(Color.appSurfaceAlt)
                        .frame(width: 72, height: 72)
                }

                // Content
                VStack(alignment: .leading, spacing: Spacing.xs) {
                    Text(record.result.title)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(Color.appText)
                        .lineLimit(1)

                    Text(record.result.estimatedPeriod)
                        .font(.appCaption)
                        .foregroundStyle(Color.appTextSecondary)
                        .lineLimit(1)

                    HStack {
                        AuthenticityBadgeView(label: record.result.authenticity, size: .small)
                        Spacer()
                        Text(record.formattedDate)
                            .font(.system(size: 11))
                            .foregroundStyle(Color.appTextTertiary)
                    }
                }

                // Chevron
                Image(systemName: "chevron.right")
                    .font(.system(size: 18))
                    .foregroundStyle(Color.appTextTertiary)
            }
            .padding(Spacing.md)
            .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
            .cardShadow()
        }
        .buttonStyle(.plain)
    }
}
