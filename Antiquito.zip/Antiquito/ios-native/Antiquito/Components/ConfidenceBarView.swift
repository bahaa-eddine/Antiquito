import SwiftUI

// MARK: - Confidence Bar View

/// Animated confidence bar with color coding and label.
struct ConfidenceBarView: View {
    let confidence: Int
    let confidenceLabel: String

    @State private var animatedProgress: CGFloat = 0

    private var barColor: Color {
        Color(hex: AIService.getBarColor(confidence))
    }

    var body: some View {
        VStack(spacing: Spacing.xs + 2) {
            HStack {
                Text(confidenceLabel)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(barColor)
                Spacer()
                Text("\(confidence)%")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(barColor)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: Radius.full)
                        .fill(Color(hex: "#E5E0D8"))
                        .frame(height: 8)

                    RoundedRectangle(cornerRadius: Radius.full)
                        .fill(barColor)
                        .frame(width: geo.size.width * animatedProgress, height: 8)
                }
            }
            .frame(height: 8)
        }
        .onAppear {
            withAnimation(.easeOut(duration: 1.1).delay(0.2)) {
                animatedProgress = CGFloat(confidence) / 100
            }
        }
    }
}
