import SwiftUI

// MARK: - Skeleton Loader View

/// Shimmer skeleton loader shown while awaiting analysis results.
struct SkeletonLoaderView: View {
    var body: some View {
        VStack(spacing: Spacing.md) {
            // Badge placeholder
            ShimmerBox()
                .frame(width: 200, height: 44)
                .clipShape(Capsule())
                .frame(maxWidth: .infinity)

            // Confidence bar skeleton
            skeletonCard {
                ShimmerBox().frame(width: 120, height: 13)
                ShimmerBox().frame(height: 8).clipShape(Capsule())
            }

            // Info card skeleton
            skeletonCard {
                ShimmerBox().frame(width: 100, height: 14).padding(.bottom, Spacing.xs)
                ShimmerBox().frame(height: 13)
                ShimmerBox().frame(width: UIScreen.main.bounds.width * 0.55, height: 13)
                ShimmerBox().frame(height: 13)
            }

            // Description skeleton
            skeletonCard {
                ShimmerBox().frame(width: 100, height: 14).padding(.bottom, Spacing.xs)
                ShimmerBox().frame(height: 13)
                ShimmerBox().frame(height: 13)
                ShimmerBox().frame(width: 140, height: 13)
            }
        }
        .padding(.horizontal, Spacing.md)
        .padding(.top, Spacing.md)
    }

    @ViewBuilder
    private func skeletonCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: Spacing.sm) {
            content()
        }
        .padding(Spacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
        .cardShadow()
    }
}

// MARK: - Shimmer Box

/// An animated shimmer placeholder rectangle.
struct ShimmerBox: View {
    @State private var opacity: Double = 0.4

    var body: some View {
        RoundedRectangle(cornerRadius: Radius.sm)
            .fill(Color.appSkeleton)
            .opacity(opacity)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.75).repeatForever(autoreverses: true)) {
                    opacity = 1
                }
            }
    }
}
