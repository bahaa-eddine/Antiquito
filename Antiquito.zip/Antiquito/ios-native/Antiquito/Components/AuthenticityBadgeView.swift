import SwiftUI

// MARK: - Authenticity Badge View

struct AuthenticityBadgeView: View {
    let label: AuthenticityLabel
    var size: BadgeSize = .large

    enum BadgeSize {
        case small, large

        var iconSize: CGFloat { self == .large ? 28 : 16 }
        var fontSize: CGFloat { self == .large ? 18 : 12 }
        var hPadding: CGFloat { self == .large ? Spacing.lg : Spacing.sm }
        var vPadding: CGFloat { self == .large ? Spacing.sm + 2 : Spacing.xs }
        var spacing: CGFloat { self == .large ? Spacing.sm : Spacing.xs }
    }

    private var config: (bg: Color, fg: Color) {
        switch label {
        case .authentic:    return (Color.appRealLight, Color.appReal)
        case .reproduction: return (Color.appFakeLight, Color.appFake)
        case .inconclusive: return (Color.appUncertainLight, Color.appUncertain)
        }
    }

    var body: some View {
        HStack(spacing: size.spacing) {
            Image(systemName: label.systemImage)
                .font(.system(size: size.iconSize))
                .foregroundStyle(config.fg)

            Text(label.displayText)
                .font(.system(size: size.fontSize, weight: .bold))
                .foregroundStyle(config.fg)
                .tracking(0.3)
        }
        .padding(.horizontal, size.hPadding)
        .padding(.vertical, size.vPadding)
        .background(config.bg, in: Capsule())
    }
}
