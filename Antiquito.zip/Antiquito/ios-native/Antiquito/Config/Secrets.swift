import Foundation

// MARK: - Secrets Configuration
// In production, use .xcconfig files or environment variables instead of hardcoding.

enum Secrets {
    /// Groq API key — set via Xcode scheme environment variable or .xcconfig
    static var groqAPIKey: String {
        ProcessInfo.processInfo.environment["GROQ_API_KEY"]
            ?? Bundle.main.infoDictionary?["GROQ_API_KEY"] as? String
            ?? ""
    }

    /// Firebase configuration is loaded from GoogleService-Info.plist automatically
}
