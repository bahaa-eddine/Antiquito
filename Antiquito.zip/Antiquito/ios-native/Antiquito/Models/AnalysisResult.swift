import Foundation

// MARK: - Analysis Result

struct AnalysisResult: Codable, Equatable {
    let authenticity: AuthenticityLabel
    let confidence: Int              // 0–100
    let confidenceLabel: String      // e.g. "Likely Authentic"
    let title: String
    let estimatedPeriod: String
    let origin: String
    let description: String
    let estimatedPrice: String?      // Market value; omitted when Inconclusive (46–55%)
    let authenticPrice: String?      // Only for Reproduction: what the genuine original is worth
}
