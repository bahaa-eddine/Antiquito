import Foundation

// MARK: - Scan Record

struct ScanRecord: Codable, Identifiable, Equatable {
    let id: String
    let imageData: Data        // JPEG data stored locally
    let result: AnalysisResult
    let createdAt: Date

    /// Formatted date for display (e.g. "Today at 2:30 PM", "Yesterday at 10:15 AM")
    var formattedDate: String {
        let calendar = Calendar.current
        let now = Date()
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "h:mm a"
        let timeStr = timeFormatter.string(from: createdAt)

        if calendar.isDateInToday(createdAt) {
            return "Today at \(timeStr)"
        } else if calendar.isDateInYesterday(createdAt) {
            return "Yesterday at \(timeStr)"
        } else {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM d"
            return "\(dateFormatter.string(from: createdAt)) at \(timeStr)"
        }
    }
}
