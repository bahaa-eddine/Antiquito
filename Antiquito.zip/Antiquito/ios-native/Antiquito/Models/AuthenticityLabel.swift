import Foundation

// MARK: - Authenticity Label

enum AuthenticityLabel: String, Codable, CaseIterable {
    case authentic    = "Authentic"
    case reproduction = "Reproduction"
    case inconclusive = "Inconclusive"

    var displayText: String {
        switch self {
        case .authentic:    return "Authentic Antique"
        case .reproduction: return "Reproduction"
        case .inconclusive: return "Inconclusive"
        }
    }

    var systemImage: String {
        switch self {
        case .authentic:    return "checkmark.circle.fill"
        case .reproduction: return "xmark.circle.fill"
        case .inconclusive: return "questionmark.circle.fill"
        }
    }
}
