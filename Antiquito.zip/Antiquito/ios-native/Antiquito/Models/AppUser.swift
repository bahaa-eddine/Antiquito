import Foundation

// MARK: - App User

struct AppUser: Codable, Equatable {
    let id: String
    let email: String
    let name: String
}
