import SwiftUI

extension Color {
    // MARK: - Backgrounds
    static let appBackground    = Color(hex: "#F7F3EE")
    static let appSurface       = Color.white
    static let appSurfaceAlt    = Color(hex: "#EDE8E0")

    // MARK: - Brand
    static let appPrimary       = Color(hex: "#8B6914")
    static let appPrimaryLight  = Color(hex: "#C8A441")
    static let appPrimaryDark   = Color(hex: "#6B4F0F")

    // MARK: - Text
    static let appText          = Color(hex: "#1C1A18")
    static let appTextSecondary = Color(hex: "#6B6560")
    static let appTextTertiary  = Color(hex: "#A09890")

    // MARK: - Authenticity
    static let appReal          = Color(hex: "#1A7340")
    static let appRealLight     = Color(hex: "#E8F5EE")
    static let appFake          = Color(hex: "#C0392B")
    static let appFakeLight     = Color(hex: "#FDECEA")
    static let appUncertain     = Color(hex: "#B7770D")
    static let appUncertainLight = Color(hex: "#FEF6E4")

    // MARK: - UI
    static let appBorder        = Color(hex: "#E8E0D5")
    static let appSeparator     = Color(hex: "#F0EBE3")
    static let appSkeleton      = Color(hex: "#E8E0D5")
    static let appOverlay       = Color.black.opacity(0.55)

    // MARK: - Hex initializer
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
