import SwiftUI

// MARK: - Spacing

enum Spacing {
    static let xs: CGFloat  = 4
    static let sm: CGFloat  = 8
    static let md: CGFloat  = 16
    static let lg: CGFloat  = 24
    static let xl: CGFloat  = 32
    static let xxl: CGFloat = 48
}

// MARK: - Radius

enum Radius {
    static let sm: CGFloat   = 8
    static let md: CGFloat   = 12
    static let lg: CGFloat   = 16
    static let xl: CGFloat   = 24
    static let full: CGFloat = 9999
}

// MARK: - Shadow

extension View {
    func cardShadow() -> some View {
        self.shadow(color: .black.opacity(0.07), radius: 8, x: 0, y: 2)
    }

    func strongShadow() -> some View {
        self.shadow(color: .black.opacity(0.12), radius: 12, x: 0, y: 4)
    }
}
