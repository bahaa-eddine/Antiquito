import SwiftUI

// MARK: - Typography

extension Font {
    static let appTitle       = Font.system(size: 28, weight: .heavy)
    static let appHeadline    = Font.system(size: 22, weight: .bold)
    static let appSubheadline = Font.system(size: 17, weight: .semibold)
    static let appBody        = Font.system(size: 15, weight: .regular)
    static let appCaption     = Font.system(size: 13, weight: .medium)
    static let appFootnote    = Font.system(size: 12, weight: .medium)
    static let appBadge       = Font.system(size: 10, weight: .bold)
    static let appStat        = Font.system(size: 28, weight: .heavy)
    static let appSectionTitle = Font.system(size: 12, weight: .bold)
}

extension Text {
    func sectionTitle() -> some View {
        self.font(.appSectionTitle)
            .foregroundStyle(Color.appTextTertiary)
            .textCase(.uppercase)
            .tracking(0.8)
    }
}
