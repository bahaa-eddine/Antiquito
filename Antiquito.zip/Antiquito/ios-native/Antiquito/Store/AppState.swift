import SwiftUI

// MARK: - App State (Observable)

/// Central app state — replaces the Zustand store from the Expo project.
/// Uses @Observable (iOS 17+) macro for automatic SwiftUI updates.
@Observable
final class AppState {
    // MARK: - Auth
    var user: AppUser? = nil
    var isAuthenticated: Bool = false
    var authReady: Bool = false

    // MARK: - Current scan session
    var capturedImageData: Data? = nil
    var analysisResult: AnalysisResult? = nil
    var isLoading: Bool = false
    var error: String? = nil

    // MARK: - Past scan viewer
    var viewingScan: ScanRecord? = nil

    // MARK: - Scan history (persisted locally)
    var scanHistory: [ScanRecord] = [] {
        didSet { persistScanHistory() }
    }

    // MARK: - Subscription
    var isPremium: Bool = false {
        didSet { UserDefaults.standard.set(isPremium, forKey: Keys.isPremium) }
    }
    var freeScansUsed: Int = 0 {
        didSet { UserDefaults.standard.set(freeScansUsed, forKey: Keys.freeScansUsed) }
    }

    // MARK: - Navigation
    var showPaywall: Bool = false
    var showCamera: Bool = false
    var showPreview: Bool = false
    var showResult: Bool = false

    // MARK: - Init

    init() {
        loadPersistedState()
    }

    // MARK: - Auth Actions

    func login(_ user: AppUser) {
        self.user = user
        self.isAuthenticated = true
    }

    func logout() {
        self.user = nil
        self.isAuthenticated = false
        resetScanSession()
    }

    // MARK: - Scan Session Actions

    func setCapturedImage(_ data: Data) {
        self.capturedImageData = data
        self.analysisResult = nil
        self.error = nil
    }

    func setAnalysisResult(_ result: AnalysisResult) {
        self.analysisResult = result
    }

    func addScanRecord(_ record: ScanRecord) {
        scanHistory.insert(record, at: 0)
    }

    func resetScanSession() {
        capturedImageData = nil
        analysisResult = nil
        isLoading = false
        error = nil
        viewingScan = nil
    }

    // MARK: - Subscription Actions

    func incrementFreeScans() {
        freeScansUsed += 1
    }

    func resetFreeScans() {
        freeScansUsed = 0
    }

    var scansRemaining: Int {
        max(0, AppConstants.freeScanLimit - freeScansUsed)
    }

    var hasFreeScanAvailable: Bool {
        isPremium || scansRemaining > 0
    }

    // MARK: - Persistence

    private enum Keys {
        static let scanHistory = "antiquito.scanHistory"
        static let isPremium = "antiquito.isPremium"
        static let freeScansUsed = "antiquito.freeScansUsed"
    }

    private func loadPersistedState() {
        isPremium = UserDefaults.standard.bool(forKey: Keys.isPremium)
        freeScansUsed = UserDefaults.standard.integer(forKey: Keys.freeScansUsed)

        if let data = UserDefaults.standard.data(forKey: Keys.scanHistory),
           let history = try? JSONDecoder().decode([ScanRecord].self, from: data) {
            scanHistory = history
        }
    }

    private func persistScanHistory() {
        if let data = try? JSONEncoder().encode(scanHistory) {
            UserDefaults.standard.set(data, forKey: Keys.scanHistory)
        }
    }
}
