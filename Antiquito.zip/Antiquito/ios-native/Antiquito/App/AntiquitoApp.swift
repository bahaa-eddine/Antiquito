import SwiftUI
import FirebaseCore

// MARK: - App Entry Point

@main
struct AntiquitoApp: App {
    @State private var appState = AppState()
    @State private var authService: AuthService?

    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if !appState.authReady {
                    // Splash / loading screen
                    ZStack {
                        Color.appBackground.ignoresSafeArea()
                        ProgressView()
                            .tint(Color.appPrimary)
                            .scaleEffect(1.5)
                    }
                } else if appState.isAuthenticated {
                    MainTabView()
                } else {
                    LoginView()
                }
            }
            .environment(appState)
            .onAppear {
                if authService == nil {
                    let service = AuthService(appState: appState)
                    service.startListening()
                    authService = service
                }
            }
            .preferredColorScheme(.light)
        }
    }
}
