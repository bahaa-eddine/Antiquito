import Foundation

// MARK: - AI Service

/// Analyzes antique images using Llama 4 Scout Vision via Groq API.
/// Replaces the Expo aiService.ts — uses URLSession + Codable instead of fetch.
enum AIService {

    private static let groqURL = URL(string: "https://api.groq.com/openai/v1/chat/completions")!
    private static let model = "meta-llama/llama-4-scout-17b-16e-instruct"

    // MARK: - System & User Prompts

    private static let systemMessage = """
    You are an expert antique appraiser with 30 years of experience. You ALWAYS give a decisive score. \
    You NEVER hedge with a score of 46–55 unless the image is literally too blurry or dark to see anything. \
    When you are unsure, you pick the most likely side — that is your professional duty.
    """

    private static let analysisPrompt = """
    Examine the image and return ONLY a raw JSON object — no markdown, no code fences, no explanation before or after.

    Required fields:
    {
      "confidence": <integer 0–100>,
      "title": "<specific object name>",
      "estimatedPeriod": "<date range e.g. 1860–1880, or 'Modern reproduction'>",
      "origin": "<country or region of manufacture>",
      "description": "<2-3 sentences explaining what you see and WHY you scored it this way>",
      "estimatedPrice": "<USD market value range>",
      "authenticPrice": "<USD range for genuine original — ONLY include when confidence is 0–45>"
    }

    Scoring guide — pick the most accurate score, AVOID 46–55:
      0–15  = Almost Certainly a Reproduction  → mass-produced, factory finish, plastic, modern branding
     16–35  = Likely a Reproduction            → strong signs of modern manufacture, inconsistencies
     36–45  = Probably a Reproduction          → suspicious, a few period features but mostly modern
     46–55  = Inconclusive                     → USE ONLY when image is too blurry/dark to evaluate
     56–70  = Probably Authentic               → multiple period-consistent features
     71–85  = Likely Authentic                 → strong patina, hand-craftsmanship, period materials
     86–100 = Highly Authentic                 → exceptional period alignment, maker marks, provenance

    Pricing:
    - Include "estimatedPrice" for confidence 0–45 (replica/resale value) and 56–100 (antique value)
    - Include "authenticPrice" for confidence 0–45 only (what the real original would sell for)
    - OMIT both price fields for confidence 46–55

    Examples of scores:
    - iPhone → confidence: 5
    - IKEA chair → confidence: 8
    - Suspicious "antique" vase with sticker → confidence: 30
    - Old coin with visible wear but uncertain origin → confidence: 62
    - Victorian ceramic with maker's mark and crazing → confidence: 82
    """

    // MARK: - Public API

    /// Analyze an image of a suspected antique.
    /// - Parameter imageData: JPEG image data.
    /// - Returns: Structured analysis result with authenticity, confidence, and pricing.
    static func analyzeImage(_ imageData: Data) async throws -> AnalysisResult {
        let apiKey = Secrets.groqAPIKey
        guard !apiKey.isEmpty else {
            throw AIServiceError.missingAPIKey
        }

        let base64 = imageData.base64EncodedString()

        let requestBody = GroqRequest(
            model: model,
            messages: [
                .init(role: "system", content: .text(systemMessage)),
                .init(role: "user", content: .multipart([
                    .init(type: "image_url", imageURL: .init(url: "data:image/jpeg;base64,\(base64)")),
                    .init(type: "text", text: analysisPrompt),
                ]))
            ],
            maxTokens: 1024,
            temperature: 0.4
        )

        var request = URLRequest(url: groqURL)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(requestBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw AIServiceError.invalidResponse
        }

        guard httpResponse.statusCode == 200 else {
            let errorText = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw AIServiceError.apiError(statusCode: httpResponse.statusCode, message: errorText)
        }

        let groqResponse = try JSONDecoder().decode(GroqResponse.self, from: data)

        guard let content = groqResponse.choices.first?.message.content, !content.isEmpty else {
            throw AIServiceError.emptyResponse
        }

        return try parseResponse(content)
    }

    // MARK: - Response Parser

    private static func parseResponse(_ content: String) throws -> AnalysisResult {
        // Strip markdown code fences if present
        var cleaned = content
            .replacingOccurrences(of: "```json", with: "", options: .caseInsensitive)
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard let jsonData = cleaned.data(using: .utf8) else {
            throw AIServiceError.parseError
        }

        let parsed = try JSONDecoder().decode(RawAnalysisResponse.self, from: jsonData)

        let confidence = max(0, min(100, parsed.confidence))

        var result = AnalysisResult(
            authenticity: getAuthenticity(confidence),
            confidence: confidence,
            confidenceLabel: getConfidenceLabel(confidence),
            title: parsed.title ?? "Unknown Object",
            estimatedPeriod: parsed.estimatedPeriod ?? "Unknown",
            origin: parsed.origin ?? "Unknown",
            description: parsed.description ?? "",
            estimatedPrice: (confidence <= 45 || confidence >= 56) ? parsed.estimatedPrice : nil,
            authenticPrice: (confidence <= 45) ? parsed.authenticPrice : nil
        )

        return result
    }

    // MARK: - Confidence Helpers

    static func getConfidenceLabel(_ confidence: Int) -> String {
        switch confidence {
        case 0...15:   return "Almost Certainly a Reproduction"
        case 16...35:  return "Likely a Reproduction"
        case 36...45:  return "Probably a Reproduction"
        case 46...55:  return "Inconclusive"
        case 56...70:  return "Probably Authentic"
        case 71...85:  return "Likely Authentic"
        default:       return "Highly Authentic"
        }
    }

    static func getAuthenticity(_ confidence: Int) -> AuthenticityLabel {
        switch confidence {
        case 0...45:   return .reproduction
        case 46...55:  return .inconclusive
        default:       return .authentic
        }
    }

    static func getBarColor(_ confidence: Int) -> String {
        switch confidence {
        case 0...15:   return "#922B21"
        case 16...35:  return "#C0392B"
        case 36...45:  return "#D35400"
        case 46...55:  return "#B7770D"
        case 56...70:  return "#27AE60"
        case 71...85:  return "#1A7340"
        default:       return "#0D5C35"
        }
    }

    // MARK: - Error Types

    enum AIServiceError: LocalizedError {
        case missingAPIKey
        case invalidResponse
        case apiError(statusCode: Int, message: String)
        case emptyResponse
        case parseError

        var errorDescription: String? {
            switch self {
            case .missingAPIKey:
                return "Groq API key not configured. Add GROQ_API_KEY to your scheme environment."
            case .invalidResponse:
                return "Invalid response from the server."
            case .apiError(let code, let message):
                return "API error (\(code)): \(message)"
            case .emptyResponse:
                return "Empty response from Groq API."
            case .parseError:
                return "Failed to parse analysis result."
            }
        }
    }
}

// MARK: - Groq API Request/Response Types

private struct GroqRequest: Encodable {
    let model: String
    let messages: [Message]
    let maxTokens: Int
    let temperature: Double

    enum CodingKeys: String, CodingKey {
        case model, messages, temperature
        case maxTokens = "max_tokens"
    }

    struct Message: Encodable {
        let role: String
        let content: Content

        enum Content: Encodable {
            case text(String)
            case multipart([ContentPart])

            func encode(to encoder: Encoder) throws {
                var container = encoder.singleValueContainer()
                switch self {
                case .text(let text):
                    try container.encode(text)
                case .multipart(let parts):
                    try container.encode(parts)
                }
            }
        }
    }

    struct ContentPart: Encodable {
        let type: String
        var imageURL: ImageURL? = nil
        var text: String? = nil

        enum CodingKeys: String, CodingKey {
            case type
            case imageURL = "image_url"
            case text
        }

        struct ImageURL: Encodable {
            let url: String
        }
    }
}

private struct GroqResponse: Decodable {
    let choices: [Choice]

    struct Choice: Decodable {
        let message: ResponseMessage
    }

    struct ResponseMessage: Decodable {
        let content: String?
    }
}

private struct RawAnalysisResponse: Decodable {
    let confidence: Int
    let title: String?
    let estimatedPeriod: String?
    let origin: String?
    let description: String?
    let estimatedPrice: String?
    let authenticPrice: String?
}
