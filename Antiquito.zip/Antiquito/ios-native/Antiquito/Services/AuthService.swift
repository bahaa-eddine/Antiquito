import Foundation
import FirebaseAuth

// MARK: - Auth Service

/// Wraps Firebase Authentication, replacing the Expo useAuthListener hook + firebase.ts service.
@Observable
final class AuthService {
    private var authHandle: AuthStateDidChangeListenerHandle?
    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
    }

    // MARK: - Auth State Listener

    /// Start listening for auth state changes. Call once at app launch.
    func startListening() {
        authHandle = Auth.auth().addStateDidChangeListener { [weak self] _, firebaseUser in
            guard let self else { return }

            if let firebaseUser {
                if firebaseUser.isEmailVerified {
                    let user = AppUser(
                        id: firebaseUser.uid,
                        email: firebaseUser.email ?? "",
                        name: firebaseUser.displayName
                            ?? firebaseUser.email?.components(separatedBy: "@").first
                            ?? "User"
                    )
                    self.appState.login(user)
                } else {
                    // Block unverified users
                    try? Auth.auth().signOut()
                    return
                }
            } else {
                self.appState.logout()
            }

            self.appState.authReady = true
        }
    }

    func stopListening() {
        if let handle = authHandle {
            Auth.auth().removeStateDidChangeListener(handle)
            authHandle = nil
        }
    }

    // MARK: - Sign In

    func signIn(email: String, password: String) async throws {
        let result = try await Auth.auth().signIn(withEmail: email, password: password)

        if !result.user.isEmailVerified {
            try Auth.auth().signOut()
            throw AuthError.emailNotVerified
        }
    }

    // MARK: - Sign Up

    func signUp(name: String, email: String, password: String) async throws {
        let result = try await Auth.auth().createUser(withEmail: email, password: password)

        let changeRequest = result.user.createProfileChangeRequest()
        changeRequest.displayName = name
        try await changeRequest.commitChanges()

        try await result.user.sendEmailVerification()

        // Sign out until they verify
        try Auth.auth().signOut()
    }

    // MARK: - Sign Out

    func signOut() throws {
        try Auth.auth().signOut()
    }

    // MARK: - Error Types

    enum AuthError: LocalizedError {
        case emailNotVerified
        case invalidCredentials
        case emailInUse
        case weakPassword
        case invalidEmail
        case unknown(String)

        var errorDescription: String? {
            switch self {
            case .emailNotVerified:
                return "Please verify your email before signing in. Check your inbox."
            case .invalidCredentials:
                return "Incorrect email or password."
            case .emailInUse:
                return "An account with this email already exists."
            case .weakPassword:
                return "Password must be at least 6 characters."
            case .invalidEmail:
                return "Please enter a valid email address."
            case .unknown(let message):
                return message
            }
        }

        static func from(_ error: Error) -> AuthError {
            let nsError = error as NSError
            guard nsError.domain == AuthErrorDomain else {
                return .unknown(error.localizedDescription)
            }
            let code = AuthErrorCode.Code(rawValue: nsError.code)
            switch code {
            case .wrongPassword, .userNotFound, .invalidCredential:
                return .invalidCredentials
            case .emailAlreadyInUse:
                return .emailInUse
            case .weakPassword:
                return .weakPassword
            case .invalidEmail:
                return .invalidEmail
            default:
                return .unknown(error.localizedDescription)
            }
        }
    }
}
