import Foundation
import StoreKit

// MARK: - StoreKit Service

/// Handles in-app subscriptions using StoreKit 2.
/// Replaces react-native-iap from the Expo project — zero external dependencies.
@Observable
final class StoreKitService {
    var products: [Product] = []
    var isPurchasing: Bool = false
    var error: String? = nil
    private var transactionListener: Task<Void, Error>?

    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
    }

    // MARK: - Start

    func start() {
        transactionListener = listenForTransactions()
        Task { await loadProducts() }
        Task { await checkCurrentEntitlements() }
    }

    func stop() {
        transactionListener?.cancel()
    }

    // MARK: - Load Products

    func loadProducts() async {
        do {
            products = try await Product.products(for: IAPConstants.allProductIDs)
                .sorted { $0.price < $1.price }
        } catch {
            self.error = "Failed to load subscription plans."
        }
    }

    // MARK: - Purchase

    func purchase(_ product: Product) async -> Bool {
        isPurchasing = true
        error = nil

        do {
            let result = try await product.purchase()

            switch result {
            case .success(let verification):
                let transaction = try checkVerified(verification)
                await transaction.finish()
                appState.isPremium = true
                isPurchasing = false
                return true

            case .userCancelled:
                isPurchasing = false
                return false

            case .pending:
                isPurchasing = false
                return false

            @unknown default:
                isPurchasing = false
                return false
            }
        } catch {
            self.error = "Purchase failed. Please try again."
            isPurchasing = false
            return false
        }
    }

    // MARK: - Restore

    func restore() async -> Bool {
        isPurchasing = true
        error = nil

        do {
            try await AppStore.sync()
            let hasActive = await checkCurrentEntitlements()

            if !hasActive {
                error = "No active subscription found to restore."
            }

            isPurchasing = false
            return hasActive
        } catch {
            self.error = "Restore failed. Please try again."
            isPurchasing = false
            return false
        }
    }

    // MARK: - Check Entitlements

    @discardableResult
    func checkCurrentEntitlements() async -> Bool {
        for await result in Transaction.currentEntitlements {
            if let transaction = try? checkVerified(result) {
                if IAPConstants.allProductIDs.contains(transaction.productID) {
                    appState.isPremium = true
                    return true
                }
            }
        }
        return false
    }

    // MARK: - Transaction Listener

    private func listenForTransactions() -> Task<Void, Error> {
        Task.detached { [weak self] in
            for await result in Transaction.updates {
                guard let self else { return }
                if let transaction = try? self.checkVerified(result) {
                    if IAPConstants.allProductIDs.contains(transaction.productID) {
                        self.appState.isPremium = true
                    }
                    await transaction.finish()
                }
            }
        }
    }

    // MARK: - Verification

    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .verified(let value):
            return value
        case .unverified(_, let error):
            throw error
        }
    }

    // MARK: - Helpers

    var weeklyProduct: Product? {
        products.first { $0.id == IAPConstants.weeklyProductID }
    }

    var monthlyProduct: Product? {
        products.first { $0.id == IAPConstants.monthlyProductID }
    }
}
