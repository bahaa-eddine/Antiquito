import Foundation

// MARK: - IAP Constants

enum IAPConstants {
    static let weeklyProductID  = "com.antiquito.premium.weekly"
    static let monthlyProductID = "com.antiquito.premium.monthly"
    static let allProductIDs: Set<String> = [weeklyProductID, monthlyProductID]
}

// MARK: - Free Scan Limit

enum AppConstants {
    static let freeScanLimit = 3
    static let appName = "ANTIQUITO"
    static let bundleIdentifier = "com.antiquito.app"
}
