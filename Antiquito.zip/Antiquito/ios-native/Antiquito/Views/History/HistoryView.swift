import SwiftUI

// MARK: - History View

/// Displays a scrollable list of past scans.
/// Matches the Expo HistoryScreen with header, scan count, empty state, and tappable cards.
struct HistoryView: View {
    @Environment(AppState.self) private var appState
    @State private var navigateToResult = false

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("My Scans")
                        .font(.appHeadline)
                        .foregroundStyle(Color.appText)
                    if !appState.scanHistory.isEmpty {
                        Text("\(appState.scanHistory.count) object\(appState.scanHistory.count != 1 ? "s" : "") analyzed")
                            .font(.appCaption)
                            .foregroundStyle(Color.appTextSecondary)
                    }
                }
                Spacer()
                PlanBadgeView {
                    if !appState.isPremium { appState.showPaywall = true }
                }
            }
            .padding(.horizontal, Spacing.lg)
            .padding(.vertical, Spacing.md)
            .overlay(alignment: .bottom) {
                Divider().foregroundStyle(Color.appSeparator)
            }

            if appState.scanHistory.isEmpty {
                emptyState
            } else {
                ScrollView {
                    LazyVStack(spacing: Spacing.sm) {
                        ForEach(appState.scanHistory) { record in
                            ScanHistoryCardView(record: record) {
                                appState.viewingScan = record
                                navigateToResult = true
                            }
                        }
                    }
                    .padding(Spacing.md)
                    .padding(.bottom, Spacing.xxl)
                }
            }
        }
        .background(Color.appBackground)
        .navigationDestination(isPresented: $navigateToResult) {
            ResultView()
        }
    }

    // MARK: - Empty State

    private var emptyState: some View {
        VStack(spacing: Spacing.md) {
            Spacer()

            Circle()
                .fill(Color.appSurfaceAlt)
                .frame(width: 96, height: 96)
                .overlay {
                    Image(systemName: "camera")
                        .font(.system(size: 44))
                        .foregroundStyle(Color.appPrimary)
                }
                .padding(.bottom, Spacing.sm)

            Text("No Scans Yet")
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(Color.appText)

            Text("Tap the camera button below to photograph your first antique and discover its history.")
                .font(.appBody)
                .foregroundStyle(Color.appTextSecondary)
                .multilineTextAlignment(.center)
                .lineSpacing(4)

            HStack(spacing: Spacing.xs) {
                Image(systemName: "arrow.down")
                    .foregroundStyle(Color.appPrimary)
                Text("Use the camera button")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Color.appPrimary)
            }
            .padding(.horizontal, Spacing.md)
            .padding(.vertical, Spacing.sm)
            .background(Color.appSurfaceAlt, in: Capsule())
            .padding(.top, Spacing.sm)

            Spacer()
            Spacer()
        }
        .padding(.horizontal, Spacing.xl)
    }
}
