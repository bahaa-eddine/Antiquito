import SwiftUI

// MARK: - Result View

/// Displays the AI analysis result or a past scan detail.
/// Matches the Expo ResultScreen — loads analysis, auto-saves to history, shows result cards.
struct ResultView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss
    @State private var hasSaved = false

    private var displayResult: AnalysisResult? {
        appState.viewingScan?.result ?? appState.analysisResult
    }

    private var displayImageData: Data? {
        appState.viewingScan?.imageData ?? appState.capturedImageData
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button { handleBack() } label: {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 22))
                        .foregroundStyle(Color.appText)
                        .frame(width: 44, height: 44)
                }
                Spacer()
                Text(appState.viewingScan != nil ? "Scan Detail" : "Analysis Result")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(Color.appText)
                    .tracking(0.2)
                Spacer()
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, Spacing.md)
            .padding(.vertical, Spacing.sm + 2)
            .background(Color.appBackground)
            .overlay(alignment: .bottom) {
                Divider().foregroundStyle(Color.appSeparator)
            }

            ScrollView {
                VStack(spacing: Spacing.md) {
                    // Thumbnail
                    if let imageData = displayImageData, let uiImage = UIImage(data: imageData) {
                        ZStack {
                            Image(uiImage: uiImage)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 200)
                                .clipped()
                                .clipShape(RoundedRectangle(cornerRadius: Radius.lg))
                                .cardShadow()

                            if appState.isLoading && appState.viewingScan == nil {
                                RoundedRectangle(cornerRadius: Radius.lg)
                                    .fill(Color.appPrimary.opacity(0.15))
                                    .frame(height: 200)
                                    .overlay {
                                        Rectangle()
                                            .fill(Color.appPrimary.opacity(0.7))
                                            .frame(maxWidth: .infinity)
                                            .frame(height: 2)
                                    }
                            }
                        }
                        .padding(.horizontal, Spacing.md)
                    }

                    // Loading skeleton
                    if appState.isLoading && appState.viewingScan == nil {
                        SkeletonLoaderView()
                    }

                    // Error state
                    if let error = appState.error {
                        errorView(error)
                    }

                    // Result content
                    if let result = displayResult {
                        resultContent(result)
                    }
                }
                .padding(.bottom, Spacing.lg)
            }
        }
        .background(Color.appBackground)
        .navigationBarBackButtonHidden()
        .task {
            guard appState.viewingScan == nil,
                  let imageData = appState.capturedImageData,
                  appState.analysisResult == nil else { return }
            await runAnalysis(imageData: imageData)
        }
        .onChange(of: appState.analysisResult) { _, newResult in
            guard let result = newResult,
                  let imageData = appState.capturedImageData,
                  !hasSaved,
                  appState.viewingScan == nil else { return }
            hasSaved = true
            appState.addScanRecord(ScanRecord(
                id: String(Date().timeIntervalSince1970),
                imageData: imageData,
                result: result,
                createdAt: Date()
            ))
        }
    }

    // MARK: - Result Content

    @ViewBuilder
    private func resultContent(_ result: AnalysisResult) -> some View {
        VStack(spacing: Spacing.md) {
            AuthenticityBadgeView(label: result.authenticity, size: .large)

            // Confidence bar
            cardContainer {
                ConfidenceBarView(
                    confidence: result.confidence,
                    confidenceLabel: result.confidenceLabel
                )
            }

            // Object details
            cardContainer {
                Text("Object Details").sectionTitle()
                infoRow(icon: "bookmark", label: "Name", value: result.title)
                Divider().foregroundStyle(Color.appSeparator)
                infoRow(icon: "calendar", label: "Estimated Period", value: result.estimatedPeriod)
                Divider().foregroundStyle(Color.appSeparator)
                infoRow(icon: "location", label: "Origin", value: result.origin)
            }

            // Expert analysis
            cardContainer {
                Text("Expert Analysis").sectionTitle()
                Text(result.description)
                    .font(.system(size: 14))
                    .foregroundStyle(Color.appTextSecondary)
                    .lineSpacing(4)
            }

            // Valuation
            if result.authenticity != .inconclusive {
                cardContainer {
                    Text(result.authenticity == .reproduction ? "Valuation" : "Estimated Value")
                        .sectionTitle()

                    if let price = result.estimatedPrice {
                        priceRow(
                            icon: "tag",
                            iconColor: Color.appPrimary,
                            label: result.authenticity == .reproduction ? "Reproduction Market Value" : "Estimated Market Value",
                            value: price,
                            valueColor: Color.appText
                        )
                    }

                    if result.authenticity == .reproduction, let authPrice = result.authenticPrice {
                        Divider().foregroundStyle(Color.appSeparator)
                        priceRow(
                            icon: "shield.checkered",
                            iconColor: Color.appReal,
                            label: "Authentic Antique Value",
                            value: authPrice,
                            valueColor: Color.appReal
                        )
                    }
                }
            }

            // Disclaimer
            Text("This analysis is AI-generated and intended for informational purposes only. For certified authentication, consult a professional appraiser.")
                .font(.appFootnote)
                .foregroundStyle(Color.appTextTertiary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, Spacing.sm)

            // Scan another
            Button {
                appState.viewingScan = nil
                appState.resetScanSession()
                appState.showCamera = true
            } label: {
                HStack(spacing: Spacing.sm) {
                    Image(systemName: "camera")
                        .font(.system(size: 20))
                    Text("Scan Another Object")
                        .font(.system(size: 17, weight: .bold))
                        .tracking(0.3)
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(Color.appPrimary, in: RoundedRectangle(cornerRadius: Radius.lg))
                .strongShadow()
            }
        }
        .padding(.horizontal, Spacing.md)
    }

    // MARK: - Error View

    @ViewBuilder
    private func errorView(_ error: String) -> some View {
        VStack(spacing: Spacing.md) {
            Image(systemName: "exclamationmark.circle")
                .font(.system(size: 56))
                .foregroundStyle(Color.appFake)
            Text("Analysis Failed")
                .font(.appHeadline)
                .foregroundStyle(Color.appText)
            Text(error)
                .font(.appBody)
                .foregroundStyle(Color.appTextSecondary)
                .multilineTextAlignment(.center)
                .lineSpacing(4)
            Button {
                appState.viewingScan = nil
                appState.resetScanSession()
                appState.showCamera = true
            } label: {
                Text("Scan Another Object")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, Spacing.xl)
                    .padding(.vertical, Spacing.md)
                    .background(Color.appPrimary, in: RoundedRectangle(cornerRadius: Radius.lg))
            }
        }
        .padding(Spacing.xl)
    }

    // MARK: - Helpers

    @ViewBuilder
    private func cardContainer<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: Spacing.sm) {
            content()
        }
        .padding(Spacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
        .cardShadow()
    }

    @ViewBuilder
    private func infoRow(icon: String, label: String, value: String) -> some View {
        HStack(alignment: .top, spacing: Spacing.md) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundStyle(Color.appPrimary)
                .frame(width: 32, height: 32)
                .background(Color.appSurfaceAlt, in: RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 2) {
                Text(label.uppercased())
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Color.appTextTertiary)
                    .tracking(0.5)
                Text(value)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Color.appText)
            }
        }
    }

    @ViewBuilder
    private func priceRow(icon: String, iconColor: Color, label: String, value: String, valueColor: Color) -> some View {
        HStack(alignment: .top, spacing: Spacing.md) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundStyle(iconColor)
                .frame(width: 32, height: 32)
                .background(iconColor.opacity(0.1), in: RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 2) {
                Text(label.uppercased())
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Color.appTextTertiary)
                    .tracking(0.5)
                Text(value)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(valueColor)
            }
        }
    }

    // MARK: - Actions

    private func handleBack() {
        if appState.viewingScan != nil {
            appState.viewingScan = nil
        }
        dismiss()
    }

    private func runAnalysis(imageData: Data) async {
        appState.isLoading = true
        appState.error = nil
        do {
            let result = try await AIService.analyzeImage(imageData)
            await MainActor.run { appState.setAnalysisResult(result) }
        } catch {
            await MainActor.run { appState.error = error.localizedDescription }
        }
        await MainActor.run { appState.isLoading = false }
    }
}
