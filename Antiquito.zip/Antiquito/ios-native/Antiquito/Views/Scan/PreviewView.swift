import SwiftUI

// MARK: - Preview View

/// Shows the captured photo with an "Analyze Object" CTA.
/// Matches the Expo PreviewScreen — includes free scan count and paywall gate.
struct PreviewView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss
    @State private var navigateToResult = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            // Full-screen image
            if let imageData = appState.capturedImageData,
               let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
            }

            // Top gradient
            VStack {
                LinearGradient(
                    colors: [.black.opacity(0.55), .clear],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(height: 140)
                Spacer()
            }
            .ignoresSafeArea()

            // Bottom gradient
            VStack {
                Spacer()
                LinearGradient(
                    colors: [.clear, .black.opacity(0.82)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .frame(height: 320)
            }
            .ignoresSafeArea()

            // Top bar
            VStack {
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 22))
                            .foregroundStyle(.white)
                            .frame(width: 44, height: 44)
                            .background(.black.opacity(0.4), in: Circle())
                    }
                    Spacer()
                    Text("Preview")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.white)
                        .tracking(0.3)
                    Spacer()
                    Color.clear.frame(width: 44, height: 44)
                }
                .padding(.horizontal, Spacing.md)
                .padding(.top, Spacing.sm)

                Spacer()
            }

            // Bottom CTA
            VStack(spacing: Spacing.sm) {
                Spacer()

                Text("Ready to analyze?")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)

                if !appState.isPremium && appState.scansRemaining < AppConstants.freeScanLimit {
                    Text("\(appState.scansRemaining) free scan\(appState.scansRemaining == 1 ? "" : "s") remaining")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color(hex: "#FFD264").opacity(0.9))
                }

                Text("Our AI will examine this object and identify its authenticity, origin, and history.")
                    .font(.system(size: 14))
                    .foregroundStyle(.white.opacity(0.65))
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
                    .padding(.bottom, Spacing.xs)

                // Analyze Button
                Button(action: handleAnalyze) {
                    HStack(spacing: Spacing.sm) {
                        Image(systemName: "viewfinder")
                            .font(.system(size: 20))
                        Text("Analyze Object")
                            .font(.system(size: 17, weight: .bold))
                            .tracking(0.3)
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(Color.appPrimary, in: RoundedRectangle(cornerRadius: Radius.lg))
                    .shadow(color: Color.appPrimary.opacity(0.4), radius: 12, x: 0, y: 4)
                }

                // Retake
                Button { dismiss() } label: {
                    Text("Retake Photo")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(.white.opacity(0.7))
                        .frame(height: 48)
                }
            }
            .padding(.horizontal, Spacing.lg)
            .padding(.bottom, Spacing.md)
        }
        .navigationBarBackButtonHidden()
        .statusBarHidden()
        .navigationDestination(isPresented: $navigateToResult) {
            ResultView()
        }
    }

    private func handleAnalyze() {
        if !appState.isPremium {
            if appState.scansRemaining <= 0 {
                appState.showPaywall = true
                return
            }
            appState.incrementFreeScans()
        }
        navigateToResult = true
    }
}
