import SwiftUI

// MARK: - Main Tab View

/// Custom tab bar with History, Camera FAB, and Account tabs.
/// Matches the Expo CustomTabBar layout with a prominent center camera button.
struct MainTabView: View {
    @Environment(AppState.self) private var appState
    @State private var selectedTab: Tab = .history
    @State private var showCamera = false
    @State private var showPaywall = false

    enum Tab { case history, account }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Tab content
                Group {
                    switch selectedTab {
                    case .history:
                        HistoryView()
                    case .account:
                        AccountView()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                // Custom tab bar
                tabBar
            }
            .navigationDestination(isPresented: $showCamera) {
                CameraView()
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
            .onChange(of: appState.showPaywall) { _, show in
                if show {
                    showPaywall = true
                    appState.showPaywall = false
                }
            }
            .onChange(of: appState.showCamera) { _, show in
                if show {
                    showCamera = true
                    appState.showCamera = false
                }
            }
        }
    }

    // MARK: - Tab Bar

    private var tabBar: some View {
        HStack {
            // History tab
            tabButton(icon: selectedTab == .history ? "clock.fill" : "clock", label: "History", isActive: selectedTab == .history) {
                selectedTab = .history
            }

            // Camera FAB
            VStack(spacing: 3) {
                Button { showCamera = true } label: {
                    Image(systemName: "camera.fill")
                        .font(.system(size: 26))
                        .foregroundStyle(.white)
                        .frame(width: 60, height: 60)
                        .background(Color.appPrimary, in: Circle())
                        .strongShadow()
                        .offset(y: -14)
                }
                .buttonStyle(.plain)

                Text("Scan")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(Color.appPrimary)
                    .offset(y: -10)
            }
            .frame(maxWidth: .infinity)

            // Account tab
            tabButton(icon: selectedTab == .account ? "person.fill" : "person", label: "Account", isActive: selectedTab == .account) {
                selectedTab = .account
            }
        }
        .padding(.top, Spacing.sm)
        .padding(.bottom, max(safeAreaBottom, Spacing.sm))
        .background(Color.appSurface)
        .overlay(alignment: .top) {
            Divider().foregroundStyle(Color.appSeparator)
        }
        .cardShadow()
    }

    @ViewBuilder
    private func tabButton(icon: String, label: String, isActive: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon)
                    .font(.system(size: 22))
                    .foregroundStyle(isActive ? Color.appPrimary : Color.appTextTertiary)
                Text(label)
                    .font(.system(size: 11, weight: isActive ? .semibold : .medium))
                    .foregroundStyle(isActive ? Color.appPrimary : Color.appTextTertiary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, Spacing.xs)
        }
        .buttonStyle(.plain)
    }

    private var safeAreaBottom: CGFloat {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }?
            .safeAreaInsets.bottom ?? 0
    }
}
