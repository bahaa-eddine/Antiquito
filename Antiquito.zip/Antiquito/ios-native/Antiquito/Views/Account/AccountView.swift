import SwiftUI

// MARK: - Account View

/// User profile, scan statistics, app info, and sign out.
/// Matches the Expo AccountScreen with avatar, stats grid, info rows, and test mode controls.
struct AccountView: View {
    @Environment(AppState.self) private var appState

    private var totalScans: Int { appState.scanHistory.count }
    private var realCount: Int { appState.scanHistory.filter { $0.result.authenticity == .authentic }.count }
    private var fakeCount: Int { appState.scanHistory.filter { $0.result.authenticity == .reproduction }.count }
    private var uncertainCount: Int { appState.scanHistory.filter { $0.result.authenticity == .inconclusive }.count }

    private var initials: String {
        guard let name = appState.user?.name else { return "?" }
        return name.split(separator: " ")
            .prefix(2)
            .compactMap { $0.first.map(String.init) }
            .joined()
            .uppercased()
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Account")
                    .font(.appHeadline)
                    .foregroundStyle(Color.appText)
                Spacer()
                PlanBadgeView {
                    if !appState.isPremium { appState.showPaywall = true }
                }
            }
            .padding(.horizontal, Spacing.lg)
            .padding(.vertical, Spacing.md)
            .overlay(alignment: .bottom) {
                Divider().foregroundStyle(Color.appSeparator)
            }

            ScrollView {
                VStack(spacing: Spacing.md) {
                    // Profile card
                    HStack(spacing: Spacing.md) {
                        Circle()
                            .fill(Color.appPrimary)
                            .frame(width: 60, height: 60)
                            .overlay {
                                Text(initials)
                                    .font(.system(size: 22, weight: .bold))
                                    .foregroundStyle(.white)
                            }

                        VStack(alignment: .leading, spacing: 2) {
                            Text(appState.user?.name ?? "")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundStyle(Color.appText)
                            Text(appState.user?.email ?? "")
                                .font(.system(size: 14))
                                .foregroundStyle(Color.appTextSecondary)
                        }
                        Spacer()
                    }
                    .padding(Spacing.md)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
                    .cardShadow()

                    // Stats section
                    Text("Scan Statistics").sectionTitle()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, Spacing.xs)

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: Spacing.sm) {
                        statCard(value: totalScans, label: "Total Scans", color: Color.appPrimary, icon: "viewfinder")
                        statCard(value: realCount, label: "Authentic", color: Color.appReal, icon: "checkmark.circle")
                        statCard(value: fakeCount, label: "Reproductions", color: Color.appFake, icon: "xmark.circle")
                        statCard(value: uncertainCount, label: "Inconclusive", color: Color.appUncertain, icon: "questionmark.circle")
                    }

                    // App info
                    VStack(alignment: .leading, spacing: Spacing.sm) {
                        Text("About").sectionTitle()
                        infoRow(icon: "info.circle", label: "Version", value: "1.0.0")
                        Divider().foregroundStyle(Color.appSeparator)
                        infoRow(icon: "shield.checkered", label: "Auth", value: "Firebase")
                        Divider().foregroundStyle(Color.appSeparator)
                        infoRow(icon: "icloud.slash", label: "Data Storage", value: "On-device only")
                    }
                    .padding(Spacing.md)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
                    .cardShadow()

                    // Sign out
                    Button {
                        let service = AuthService(appState: appState)
                        try? service.signOut()
                    } label: {
                        HStack(spacing: Spacing.sm) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 20))
                            Text("Sign Out")
                                .font(.system(size: 16, weight: .semibold))
                        }
                        .foregroundStyle(Color.appFake)
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                        .background(Color.appFakeLight, in: RoundedRectangle(cornerRadius: Radius.lg))
                    }
                    .padding(.top, Spacing.sm)
                }
                .padding(Spacing.md)
                .padding(.bottom, Spacing.xxl)
            }
        }
        .background(Color.appBackground)
    }

    // MARK: - Stat Card

    @ViewBuilder
    private func statCard(value: Int, label: String, color: Color, icon: String) -> some View {
        VStack(spacing: Spacing.xs) {
            Image(systemName: icon)
                .font(.system(size: 22))
                .foregroundStyle(color)
            Text("\(value)")
                .font(.appStat)
                .foregroundStyle(color)
            Text(label)
                .font(.appFootnote)
                .foregroundStyle(Color.appTextSecondary)
        }
        .padding(Spacing.md)
        .frame(maxWidth: .infinity)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
        .cardShadow()
    }

    // MARK: - Info Row

    @ViewBuilder
    private func infoRow(icon: String, label: String, value: String) -> some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 17))
                .foregroundStyle(Color.appPrimary)
            Text(label)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(Color.appText)
            Spacer()
            Text(value)
                .font(.system(size: 14))
                .foregroundStyle(Color.appTextSecondary)
        }
        .padding(.vertical, 2)
    }
}
