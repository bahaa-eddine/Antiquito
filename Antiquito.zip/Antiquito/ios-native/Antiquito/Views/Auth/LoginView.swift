import SwiftUI

// MARK: - Login View

/// Full-featured login/signup screen matching the Expo LoginScreen.
/// Supports sign in, sign up with email verification, error handling, and mode toggling.
struct LoginView: View {
    @Environment(AppState.self) private var appState
    @State private var authService: AuthService?

    @State private var mode: AuthMode = .signIn
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var showPassword = false
    @State private var showConfirmPassword = false
    @State private var error = ""
    @State private var loading = false
    @State private var verificationSent = false

    private var isSignUp: Bool { mode == .signUp }

    enum AuthMode {
        case signIn, signUp
    }

    var body: some View {
        ScrollView {
            VStack(spacing: Spacing.lg) {
                // MARK: - Logo Section
                VStack(spacing: Spacing.sm) {
                    Circle()
                        .fill(Color.appSurfaceAlt)
                        .frame(width: 80, height: 80)
                        .cardShadow()
                        .overlay {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 36))
                                .foregroundStyle(Color.appPrimary)
                        }

                    Text("ANTIQUITO")
                        .font(.system(size: 28, weight: .heavy))
                        .foregroundStyle(Color.appPrimary)
                        .tracking(4)

                    Text("Discover the story behind every antique")
                        .font(.appCaption)
                        .foregroundStyle(Color.appTextSecondary)
                        .multilineTextAlignment(.center)
                }

                // MARK: - Verification Banner
                if verificationSent {
                    HStack(alignment: .top, spacing: Spacing.sm) {
                        Image(systemName: "envelope")
                            .foregroundStyle(Color.appReal)
                        Text("Verification email sent! Check your inbox, click the link, then sign in below.")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(Color.appReal)
                    }
                    .padding(Spacing.md)
                    .background(Color.appRealLight, in: RoundedRectangle(cornerRadius: Radius.lg))
                }

                // MARK: - Form Card
                VStack(spacing: Spacing.md) {
                    // Mode Toggle
                    HStack(spacing: 0) {
                        modeToggleButton("Sign In", isActive: mode == .signIn) {
                            switchMode(.signIn)
                        }
                        modeToggleButton("Create Account", isActive: mode == .signUp) {
                            switchMode(.signUp)
                        }
                    }
                    .padding(3)
                    .background(Color.appSurfaceAlt, in: RoundedRectangle(cornerRadius: Radius.md))

                    // Name Field (sign up only)
                    if isSignUp {
                        inputField(
                            label: "Full Name",
                            icon: "person",
                            placeholder: "Your name",
                            text: $name,
                            capitalization: .words
                        )
                    }

                    // Email Field
                    inputField(
                        label: "Email",
                        icon: "envelope",
                        placeholder: "you@example.com",
                        text: $email,
                        keyboardType: .emailAddress,
                        capitalization: .never
                    )

                    // Password Field
                    passwordField(
                        label: "Password",
                        placeholder: "Min. 6 characters",
                        text: $password,
                        showPassword: $showPassword
                    )

                    // Confirm Password (sign up only)
                    if isSignUp {
                        passwordField(
                            label: "Confirm Password",
                            placeholder: "Repeat your password",
                            text: $confirmPassword,
                            showPassword: $showConfirmPassword
                        )
                    }

                    // Error Message
                    if !error.isEmpty {
                        HStack(spacing: Spacing.xs) {
                            Image(systemName: "exclamationmark.circle")
                                .font(.system(size: 15))
                            Text(error)
                                .font(.system(size: 13))
                        }
                        .foregroundStyle(Color.appFake)
                    }

                    // Submit Button
                    Button(action: handleSubmit) {
                        Group {
                            if loading {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text(isSignUp ? "Create Account" : "Sign In")
                                    .font(.system(size: 16, weight: .bold))
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 52)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.white)
                    .background(Color.appPrimary.opacity(loading ? 0.7 : 1), in: RoundedRectangle(cornerRadius: Radius.lg))
                    .strongShadow()
                    .disabled(loading)
                }
                .padding(Spacing.lg)
                .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.xl))
                .cardShadow()

                Text("Your account is securely managed by Firebase Authentication.")
                    .font(.appFootnote)
                    .foregroundStyle(Color.appTextTertiary)
                    .multilineTextAlignment(.center)
            }
            .padding(.horizontal, Spacing.lg)
            .padding(.vertical, Spacing.xl)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Color.appBackground)
        .onAppear {
            if authService == nil {
                authService = AuthService(appState: appState)
                authService?.startListening()
            }
        }
    }

    // MARK: - Subviews

    @ViewBuilder
    private func modeToggleButton(_ title: String, isActive: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: isActive ? .semibold : .medium))
                .foregroundStyle(isActive ? Color.appText : Color.appTextTertiary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, Spacing.sm)
                .background(
                    isActive ? Color.appSurface : Color.clear,
                    in: RoundedRectangle(cornerRadius: Radius.sm + 2)
                )
                .cardShadow()
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func inputField(
        label: String,
        icon: String,
        placeholder: String,
        text: Binding<String>,
        keyboardType: UIKeyboardType = .default,
        capitalization: TextInputAutocapitalization = .sentences
    ) -> some View {
        VStack(alignment: .leading, spacing: Spacing.xs) {
            Text(label.uppercased())
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(Color.appTextSecondary)
                .tracking(0.5)

            HStack(spacing: Spacing.sm) {
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundStyle(Color.appTextTertiary)
                TextField(placeholder, text: text)
                    .font(.system(size: 15))
                    .foregroundStyle(Color.appText)
                    .keyboardType(keyboardType)
                    .textInputAutocapitalization(capitalization)
                    .autocorrectionDisabled()
            }
            .padding(.horizontal, Spacing.md)
            .frame(height: 48)
            .background(Color.appBackground, in: RoundedRectangle(cornerRadius: Radius.md))
            .overlay(
                RoundedRectangle(cornerRadius: Radius.md)
                    .stroke(Color.appBorder, lineWidth: 1)
            )
        }
    }

    @ViewBuilder
    private func passwordField(
        label: String,
        placeholder: String,
        text: Binding<String>,
        showPassword: Binding<Bool>
    ) -> some View {
        VStack(alignment: .leading, spacing: Spacing.xs) {
            Text(label.uppercased())
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(Color.appTextSecondary)
                .tracking(0.5)

            HStack(spacing: Spacing.sm) {
                Image(systemName: "lock")
                    .font(.system(size: 18))
                    .foregroundStyle(Color.appTextTertiary)

                Group {
                    if showPassword.wrappedValue {
                        TextField(placeholder, text: text)
                    } else {
                        SecureField(placeholder, text: text)
                    }
                }
                .font(.system(size: 15))
                .foregroundStyle(Color.appText)
                .textInputAutocapitalization(.never)

                Button {
                    showPassword.wrappedValue.toggle()
                } label: {
                    Image(systemName: showPassword.wrappedValue ? "eye.slash" : "eye")
                        .font(.system(size: 18))
                        .foregroundStyle(Color.appTextTertiary)
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, Spacing.md)
            .frame(height: 48)
            .background(Color.appBackground, in: RoundedRectangle(cornerRadius: Radius.md))
            .overlay(
                RoundedRectangle(cornerRadius: Radius.md)
                    .stroke(Color.appBorder, lineWidth: 1)
            )
        }
    }

    // MARK: - Actions

    private func switchMode(_ newMode: AuthMode) {
        withAnimation(.easeInOut(duration: 0.2)) {
            mode = newMode
            error = ""
            verificationSent = false
            confirmPassword = ""
        }
    }

    private func validate() -> String? {
        if isSignUp && name.trimmingCharacters(in: .whitespaces).count < 2 {
            return "Please enter your name."
        }
        if !email.contains("@") || !email.contains(".") {
            return "Enter a valid email address."
        }
        if password.count < 6 {
            return "Password must be at least 6 characters."
        }
        if isSignUp && password != confirmPassword {
            return "Passwords do not match."
        }
        return nil
    }

    private func handleSubmit() {
        if let validationError = validate() {
            error = validationError
            return
        }

        error = ""
        loading = true

        Task {
            do {
                let service = AuthService(appState: appState)
                if isSignUp {
                    try await service.signUp(
                        name: name.trimmingCharacters(in: .whitespaces),
                        email: email.trimmingCharacters(in: .whitespaces),
                        password: password
                    )
                    await MainActor.run {
                        verificationSent = true
                        mode = .signIn
                        name = ""
                        password = ""
                        confirmPassword = ""
                    }
                } else {
                    try await service.signIn(
                        email: email.trimmingCharacters(in: .whitespaces),
                        password: password
                    )
                }
            } catch let authError as AuthService.AuthError {
                await MainActor.run { error = authError.localizedDescription }
            } catch {
                let mapped = AuthService.AuthError.from(error)
                await MainActor.run { self.error = mapped.localizedDescription }
            }

            await MainActor.run { loading = false }
        }
    }
}
