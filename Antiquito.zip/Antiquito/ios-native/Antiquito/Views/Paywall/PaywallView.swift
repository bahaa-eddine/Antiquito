import SwiftUI
import StoreKit

// MARK: - Paywall View

/// Subscription paywall with benefits, product cards, subscribe/restore.
/// Matches the Expo PaywallScreen with hero, benefits list, product selection, and legal note.
struct PaywallView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss
    @State private var storeService: StoreKitService?
    @State private var selectedProductID = IAPConstants.monthlyProductID

    private let benefits = [
        ("viewfinder", "Unlimited daily scans"),
        ("bolt", "Priority AI analysis"),
        ("clock", "Full scan history access"),
        ("shield.checkered", "Detailed authenticity reports"),
        ("star", "Support independent development"),
    ]

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button { dismiss() } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 22))
                        .foregroundStyle(Color.appTextSecondary)
                        .frame(width: 44, height: 44)
                        .background(Color.appSurfaceAlt, in: Circle())
                }
                Spacer()
                Text("Go Premium")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(Color.appText)
                Spacer()
                Color.clear.frame(width: 44, height: 44)
            }
            .padding(.horizontal, Spacing.md)
            .padding(.vertical, Spacing.sm)
            .background(Color.appSurface)
            .overlay(alignment: .bottom) {
                Divider().foregroundStyle(Color.appSeparator)
            }

            ScrollView {
                VStack(spacing: Spacing.lg) {
                    // Hero
                    VStack(spacing: Spacing.sm) {
                        Circle()
                            .fill(Color.appSurfaceAlt)
                            .frame(width: 80, height: 80)
                            .cardShadow()
                            .overlay {
                                Image(systemName: "trophy.fill")
                                    .font(.system(size: 40))
                                    .foregroundStyle(Color.appPrimary)
                            }

                        Text("Unlock Unlimited Scans")
                            .font(.system(size: 24, weight: .heavy))
                            .foregroundStyle(Color.appText)
                            .tracking(0.2)

                        Text("You've used your \(AppConstants.freeScanLimit) free scans for today.\nUpgrade to continue analyzing antiques.")
                            .font(.system(size: 14))
                            .foregroundStyle(Color.appTextSecondary)
                            .multilineTextAlignment(.center)
                            .lineSpacing(3)
                    }

                    // Benefits
                    VStack(spacing: Spacing.sm) {
                        ForEach(benefits, id: \.0) { icon, text in
                            HStack(spacing: Spacing.md) {
                                Image(systemName: icon)
                                    .font(.system(size: 18))
                                    .foregroundStyle(Color.appPrimary)
                                    .frame(width: 36, height: 36)
                                    .background(Color.appSurfaceAlt, in: Circle())
                                Text(text)
                                    .font(.system(size: 15, weight: .medium))
                                    .foregroundStyle(Color.appText)
                                Spacer()
                            }
                        }
                    }
                    .padding(Spacing.md)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.xl))
                    .cardShadow()

                    // Product cards
                    if let service = storeService, !service.products.isEmpty {
                        VStack(spacing: Spacing.sm) {
                            if let monthly = service.monthlyProduct {
                                productCard(
                                    product: monthly,
                                    isSelected: selectedProductID == IAPConstants.monthlyProductID,
                                    isBestValue: true
                                )
                            }
                            if let weekly = service.weeklyProduct {
                                productCard(
                                    product: weekly,
                                    isSelected: selectedProductID == IAPConstants.weeklyProductID,
                                    isBestValue: false
                                )
                            }
                        }
                    } else {
                        VStack(spacing: Spacing.sm) {
                            ProgressView().tint(Color.appPrimary)
                            Text("Loading plans…")
                                .font(.system(size: 14))
                                .foregroundStyle(Color.appTextSecondary)
                        }
                        .padding(.vertical, Spacing.xl)
                    }

                    // Error
                    if let error = storeService?.error {
                        HStack(spacing: Spacing.xs) {
                            Image(systemName: "exclamationmark.circle")
                                .font(.system(size: 15))
                            Text(error)
                                .font(.system(size: 13))
                        }
                        .foregroundStyle(Color.appFake)
                        .padding(Spacing.md)
                        .background(Color.appFakeLight, in: RoundedRectangle(cornerRadius: Radius.md))
                    }

                    // Subscribe button
                    Button {
                        Task { await handleSubscribe() }
                    } label: {
                        Group {
                            if storeService?.isPurchasing == true {
                                ProgressView().tint(.white)
                            } else {
                                Text("Subscribe Now")
                                    .font(.system(size: 17, weight: .bold))
                                    .tracking(0.3)
                            }
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(Color.appPrimary, in: RoundedRectangle(cornerRadius: Radius.lg))
                        .strongShadow()
                    }
                    .disabled(storeService?.isPurchasing ?? false || storeService?.products.isEmpty ?? true)
                    .opacity((storeService?.isPurchasing ?? false || storeService?.products.isEmpty ?? true) ? 0.6 : 1)

                    // Legal note
                    Text("Subscriptions auto-renew unless cancelled at least 24 hours before the renewal date. Manage or cancel in your account settings.")
                        .font(.system(size: 11))
                        .foregroundStyle(Color.appTextTertiary)
                        .multilineTextAlignment(.center)
                        .lineSpacing(2)

                    // Restore
                    Button {
                        Task { await handleRestore() }
                    } label: {
                        Text("Restore Purchases")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(Color.appPrimary)
                            .underline()
                    }
                    .disabled(storeService?.isPurchasing ?? false)
                }
                .padding(.horizontal, Spacing.lg)
                .padding(.vertical, Spacing.lg)
                .padding(.bottom, Spacing.xl)
            }
        }
        .background(Color.appBackground)
        .onAppear {
            if storeService == nil {
                let service = StoreKitService(appState: appState)
                storeService = service
                service.start()
            }
        }
        .onChange(of: appState.isPremium) { _, isPremium in
            if isPremium { dismiss() }
        }
    }

    // MARK: - Product Card

    @ViewBuilder
    private func productCard(product: Product, isSelected: Bool, isBestValue: Bool) -> some View {
        Button {
            selectedProductID = product.id
        } label: {
            VStack(alignment: .leading, spacing: 0) {
                if isBestValue {
                    Text("BEST VALUE")
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundStyle(.white)
                        .tracking(1)
                        .padding(.horizontal, Spacing.md)
                        .padding(.vertical, 3)
                        .background(Color.appPrimary)
                }

                HStack(spacing: Spacing.sm) {
                    Image(systemName: isSelected ? "largecircle.fill.circle" : "circle")
                        .font(.system(size: 22))
                        .foregroundStyle(isSelected ? Color.appPrimary : Color.appTextTertiary)
                        .frame(width: 24)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(product.displayName)
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(Color.appText)
                        Text(isBestValue ? "Billed monthly" : "Billed weekly")
                            .font(.system(size: 13))
                            .foregroundStyle(Color.appTextSecondary)
                    }

                    Spacer()

                    Text(product.displayPrice)
                        .font(.system(size: 17, weight: .heavy))
                        .foregroundStyle(Color.appPrimary)
                }
                .padding(.horizontal, Spacing.md)
                .padding(.vertical, Spacing.md)
            }
            .background(isSelected ? Color(hex: "#FBF8F2") : Color.appSurface, in: RoundedRectangle(cornerRadius: Radius.lg))
            .overlay(
                RoundedRectangle(cornerRadius: Radius.lg)
                    .stroke(isSelected ? Color.appPrimary : Color.appBorder, lineWidth: 2)
            )
            .cardShadow()
        }
        .buttonStyle(.plain)
    }

    // MARK: - Actions

    private func handleSubscribe() async {
        guard let service = storeService,
              let product = service.products.first(where: { $0.id == selectedProductID }) else { return }
        _ = await service.purchase(product)
    }

    private func handleRestore() async {
        guard let service = storeService else { return }
        _ = await service.restore()
    }
}
