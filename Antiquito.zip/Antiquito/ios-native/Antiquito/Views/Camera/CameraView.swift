import SwiftUI
import AVFoundation

// MARK: - Camera Preview Layer (UIViewRepresentable)

/// Wraps AVCaptureVideoPreviewLayer in a SwiftUI view.
struct CameraPreviewLayer: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        context.coordinator.previewLayer = previewLayer
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            context.coordinator.previewLayer?.frame = uiView.bounds
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    class Coordinator {
        var previewLayer: AVCaptureVideoPreviewLayer?
    }
}

// MARK: - Camera Manager

/// Manages AVCaptureSession for photo capture — replaces the Expo useCamera hook.
@Observable
final class CameraManager: NSObject {
    let session = AVCaptureSession()
    var isReady = false
    var isTaking = false
    var currentPosition: AVCaptureDevice.Position = .back
    var flashMode: AVCaptureDevice.FlashMode = .off

    private let photoOutput = AVCapturePhotoOutput()
    private var captureCompletion: ((Data?) -> Void)?

    override init() {
        super.init()
    }

    func configure() {
        guard !isReady else { return }

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }

            self.session.beginConfiguration()
            self.session.sessionPreset = .photo

            // Add camera input
            guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let input = try? AVCaptureDeviceInput(device: camera),
                  self.session.canAddInput(input) else {
                self.session.commitConfiguration()
                return
            }
            self.session.addInput(input)

            // Add photo output
            guard self.session.canAddOutput(self.photoOutput) else {
                self.session.commitConfiguration()
                return
            }
            self.session.addOutput(self.photoOutput)

            self.session.commitConfiguration()
            self.session.startRunning()

            DispatchQueue.main.async { self.isReady = true }
        }
    }

    func stopSession() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self, self.session.isRunning else { return }
            self.session.stopRunning()
        }
    }

    func resumeSession() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self, !self.session.isRunning else { return }
            self.session.startRunning()
        }
    }

    func toggleFacing() {
        let newPosition: AVCaptureDevice.Position = currentPosition == .back ? .front : .back

        guard let newCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: newPosition),
              let newInput = try? AVCaptureDeviceInput(device: newCamera) else { return }

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            self.session.beginConfiguration()
            for input in self.session.inputs {
                self.session.removeInput(input)
            }
            if self.session.canAddInput(newInput) {
                self.session.addInput(newInput)
                DispatchQueue.main.async { self.currentPosition = newPosition }
            }
            self.session.commitConfiguration()
        }
    }

    func toggleFlash() {
        flashMode = flashMode == .off ? .on : .off
    }

    func takePicture() async -> Data? {
        guard !isTaking else { return nil }
        isTaking = true

        return await withCheckedContinuation { continuation in
            captureCompletion = { [weak self] data in
                self?.isTaking = false
                continuation.resume(returning: data)
            }

            let settings = AVCapturePhotoSettings()
            settings.flashMode = flashMode
            photoOutput.capturePhoto(with: settings, delegate: self)
        }
    }
}

extension CameraManager: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let data = photo.fileDataRepresentation()
        captureCompletion?(data)
        captureCompletion = nil
    }
}

// MARK: - Camera View

struct CameraView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss
    @State private var camera = CameraManager()
    @State private var flashOpacity: Double = 0
    @State private var navigateToPreview = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if camera.isReady {
                CameraPreviewLayer(session: camera.session)
                    .ignoresSafeArea()
            }

            // Flash overlay
            Color.white
                .opacity(flashOpacity)
                .ignoresSafeArea()
                .allowsHitTesting(false)

            // Top controls
            VStack {
                HStack {
                    // Flash toggle
                    Button {
                        camera.toggleFlash()
                    } label: {
                        Image(systemName: camera.flashMode == .on ? "bolt.fill" : "bolt.slash.fill")
                            .font(.system(size: 22))
                            .foregroundStyle(camera.flashMode == .on ? .yellow : .white)
                            .frame(width: 44, height: 44)
                            .background(.black.opacity(0.35), in: Circle())
                    }

                    Spacer()

                    Text("ANTIQUITO")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.white)
                        .tracking(3)

                    Spacer()

                    PlanBadgeView(dark: true) {
                        dismiss()
                    }
                }
                .padding(.horizontal, Spacing.lg)
                .padding(.top, Spacing.sm)

                Spacer()

                // Hint
                Text("Point camera at any antique object")
                    .font(.system(size: 13))
                    .foregroundStyle(.white.opacity(0.6))
                    .tracking(0.3)
                    .padding(.bottom, Spacing.md)

                // Bottom gradient + controls
                ZStack {
                    LinearGradient(
                        colors: [.clear, .black.opacity(0.72)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .frame(height: 200)

                    HStack {
                        // Flip camera
                        Button {
                            camera.toggleFacing()
                        } label: {
                            Image(systemName: "arrow.triangle.2.circlepath.camera")
                                .font(.system(size: 28))
                                .foregroundStyle(.white)
                                .frame(width: 44, height: 44)
                                .background(.white.opacity(0.15), in: Circle())
                        }

                        Spacer()

                        // Shutter
                        Button {
                            handleCapture()
                        } label: {
                            Circle()
                                .stroke(.white, lineWidth: 4)
                                .frame(width: 76, height: 76)
                                .overlay {
                                    Circle()
                                        .fill(.white)
                                        .frame(width: 62, height: 62)
                                }
                        }
                        .disabled(camera.isTaking)
                        .opacity(camera.isTaking ? 0.6 : 1)

                        Spacer()

                        // Spacer mirror
                        Color.clear.frame(width: 44, height: 44)
                    }
                    .padding(.horizontal, Spacing.xl + Spacing.sm)
                }
            }
        }
        .statusBarHidden()
        .onAppear {
            if camera.isReady {
                camera.resumeSession()
            } else {
                camera.configure()
            }
        }
        .onDisappear { camera.stopSession() }
        .navigationDestination(isPresented: $navigateToPreview) {
            PreviewView()
        }
    }

    private func handleCapture() {
        // Flash animation
        withAnimation(.easeOut(duration: 0.06)) { flashOpacity = 1 }
        withAnimation(.easeIn(duration: 0.18).delay(0.06)) { flashOpacity = 0 }

        Task {
            if let data = await camera.takePicture() {
                appState.setCapturedImage(data)
                navigateToPreview = true
            }
        }
    }
}
